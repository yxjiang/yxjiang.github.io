package eventsum.basic;

/**
 * A system event. It may have a lot of instances.
 * @author Yexi Jiang <http://sites.google.com/site/yexijiang/>
 *
 */
public class Event{
	private String type;
	private String source;
	private String category;
	private int eventID;
	
	public Event(String type, String source, String category, int eventID) {
		super();
		this.type = type;
		this.source = source;
		this.category = category;
		this.eventID = eventID;
	}

	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
	public int getEventID() {
		return eventID;
	}
	
	public void setEvent(int event) {
		this.eventID = event;
	}
	
	public String toString(){
		return "(" + eventID + "," + source + ")" ;
	}
	
	public int hashCode(){
		return eventID + source.hashCode();
	}
	
	public boolean equals(Object otherEvent){
		if(otherEvent instanceof Event){
			Event event = (Event)otherEvent;
			if(this.source.equals(event.getSource()) && this.eventID == event.getEventID() 
				/*&& this.category.equals(event.getCategory()) && this.type.equals(event.getType())*/){
				return true;
			}
			return false;
		}
		return false;
	}
		
}
