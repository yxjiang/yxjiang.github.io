package eventsum.basic;

public abstract class Pattern {
	protected int patternLength;
	protected long firstPeriod;
	protected long secondPeriod;
	
	protected int start, end;
	protected int instanceNumber;
	protected int resolution;
	
	public Pattern(int patternLength, long firstPeriod, long secondPeriod){
		this.patternLength = patternLength;
		this.firstPeriod = firstPeriod;
		this.secondPeriod = secondPeriod;
		if(this.secondPeriod <= 0){
			this.secondPeriod = this.firstPeriod;
		}
	}
	
	public Pattern(int start, int end, long firstPeriod, long secondPeriod, int resolution, int instanceNumber){
		this.start = start;
		this.end = end;
		this.firstPeriod = firstPeriod;
		this.secondPeriod = secondPeriod;
		this.resolution = resolution;
		this.instanceNumber = instanceNumber;
		this.patternLength = end - start;
	}

	public int getPatternLength() {
		return patternLength;
	}

	public void setPatternLength(int patternLength) {
		this.patternLength = patternLength;
	}

	public long getFirstPeriod() {
		return firstPeriod;
	}

	public void setFirstPeriod(int firstPeriod) {
		this.firstPeriod = firstPeriod;
	}

	public long getSecondPeriod() {
		return secondPeriod;
	}

	public void setSecondPeriod(int secondPeriod) {
		this.secondPeriod = secondPeriod;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	public int getInstanceNumber() {
		return instanceNumber;
	}

	public void setInstanceNumber(int instanceNumber) {
		this.instanceNumber = instanceNumber;
	}

	public int getResolution() {
		return resolution;
	}

	public void setResolution(int resolution) {
		this.resolution = resolution;
	}

	public void setFirstPeriod(long firstPeriod) {
		this.firstPeriod = firstPeriod;
	}

	public void setSecondPeriod(long secondPeriod) {
		this.secondPeriod = secondPeriod;
	}
	
	
}
