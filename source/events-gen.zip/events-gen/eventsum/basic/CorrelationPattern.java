package eventsum.basic;

public class CorrelationPattern extends Pattern {

	private Event primaryEventType;
	private Event secondaryEventType;
	
	public CorrelationPattern(int patternLength, long firstPeriod,
			long secondPeriod, Event primaryEventType, Event secondaryEventType) {
		super(patternLength, firstPeriod, secondPeriod);
		this.primaryEventType = primaryEventType;
		this.secondaryEventType = secondaryEventType;
	}
	
	public CorrelationPattern(int start, int end, long firstPeriod, long secondPeriod, Event primaryEventType, Event secondaryEventType, int resolution, int instanceNumber){
		super(start, end, firstPeriod, secondPeriod, resolution, instanceNumber);
		this.primaryEventType = primaryEventType;
		this.secondaryEventType = secondaryEventType;
	}

	public Event getPrimaryEventType() {
		return primaryEventType;
	}

	public void setPrimaryEventType(Event primaryEventType) {
		this.primaryEventType = primaryEventType;
	}

	public Event getSecondaryEventType() {
		return secondaryEventType;
	}

	public void setSecondaryEventType(Event secondaryEventType) {
		this.secondaryEventType = secondaryEventType;
	}
	
	public String toString(){
		String description = "Correlation pattern for " + this.primaryEventType + " and " + this.secondaryEventType 
			+ ", during " + "(" + start + "," + end + ") with interval " + this.firstPeriod;
		
		if(this.secondPeriod != 0){
			description += " and " + this.secondPeriod;
		}
		
		description += ", under resolution " + this.resolution;
		description += ", number of instances is " + this.instanceNumber;
		
		return description;
	}
	
}
