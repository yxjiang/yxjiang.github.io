package eventsum.basic;

public class PeriodPattern extends Pattern{

	private Event eventType;

	public PeriodPattern(int patternLength, long firstPeriod, long secondPeriod,
			Event eventType) {
		super(patternLength, firstPeriod, secondPeriod);
		this.eventType = eventType;
	}
	
	public PeriodPattern(int start, int end, long firstPeriod, long secondPeriod,
			Event eventType, int resolution, int instanceNumber) {
		super(start, end, firstPeriod, secondPeriod, resolution, instanceNumber);
		this.eventType = eventType;
	}

	public Event getEventType() {
		return eventType;
	}

	public void setEventType(Event eventType) {
		this.eventType = eventType;
	}
	
	public String toString(){
		String description = "Period pattern for " + eventType + ", during " 
			+ "(" + start + "," + end + ") with interval " + this.firstPeriod;
		
		if(this.secondPeriod != 0){
			description += " and " + this.secondPeriod;
		}
		
		description += ", under resolution " + this.resolution;
		
		description += ", number of instances is " + this.instanceNumber;
		
		return description;
	}
	
}
