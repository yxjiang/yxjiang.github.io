package eventsum.experiments;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import eventsum.basic.CorrelationPattern;
import eventsum.basic.Event;
import eventsum.basic.Pattern;
import eventsum.basic.PeriodPattern;

/**
 * Synthetic data generator.
 * 
 *	@author Yexi Jiang <http://users.cis.fiu.edu/~yjian004/>
 *	@date 2011-1-29
 */
public class SyntheticDataGenerator {
	
	/**
	 * Generate a sequence of period pattern.
	 * @param pattern	The specified period pattern.
	 * @param writer	The instance of file writer
	 * @param noiseRate	The proportion of noise.
	 * @throws IOException 
	 */
	private void generatePeriodPattern(PeriodPattern pattern, FileWriter writer, double noiseRate, double randomRate) throws IOException{
		Event eventType = pattern.getEventType();
		long curMillTime = System.currentTimeMillis();
		long firstPeriod = pattern.getFirstPeriod();
		long secondPeriod = pattern.getSecondPeriod();
		int length = pattern.getPatternLength();

		int count = 0;
		
		for(int i = 0; i < length; ++i){
			double random = Math.random();
			
			if(i % 2 == 0){
				curMillTime += firstPeriod * 1000;
				//	add noise
				if(random < noiseRate){
					curMillTime += random * 100000;
					++count;
				}
			}
			else{
				curMillTime += secondPeriod * 1000;
				//	add noise
				if(random < noiseRate){
					curMillTime += random * 100000;
					++count;
				}
			}
			
			Date date = new Date(curMillTime);
			Calendar cl = Calendar.getInstance();
			cl.setTime(date);
			String strDate = cl.get(Calendar.YEAR) + "-" + cl.get(Calendar.MONTH) + "-" + cl.get(Calendar.DATE);
			String strTime = cl.get(Calendar.HOUR_OF_DAY) + ":" + cl.get(Calendar.MINUTE) + ":" + cl.get(Calendar.SECOND);
			String strData = eventType.getType() + "\t" + strDate + "\t" + strTime + "\t" + eventType.getSource() 
								+ "\t" + eventType.getCategory() + "\t" + eventType.getEventID() + "\tSynthetic\tDummy\n";
			writer.write(strData);
		}
		
	}
	
	/**
	 * Generate a sequence of correlation pattern.
	 * @param pattern	The specified correlation pattern.
	 * @param writer	The instance of file writer.
	 * @param noiseRate	The proportion of noise.
	 * @throws IOException 
	 */
	private void generateCorrelationPattern(CorrelationPattern pattern, FileWriter writer, double noiseRate, double randomRate) throws IOException{
		Event primaryEventType = pattern.getPrimaryEventType();
		Event secondaryEventType = pattern.getSecondaryEventType();
		long curMillTime = System.currentTimeMillis();
		long firstPeriod = pattern.getFirstPeriod();
		long secondPeriod = pattern.getSecondPeriod();
		int length = pattern.getPatternLength();
		
		long millTime = curMillTime;
		for(int i = 0; i < length; ++i){
			double random = Math.random();
			
			millTime += (Math.random() * 10) * 1000;

			Date primaryDate = new Date(millTime);
			Calendar primaryCl = Calendar.getInstance();
			primaryCl.setTime(primaryDate);
			String strPrimaryDate = primaryCl.get(Calendar.YEAR) + "-" + primaryCl.get(Calendar.MONTH) + "-" + primaryCl.get(Calendar.DATE);
			String strPrimaryTime = primaryCl.get(Calendar.HOUR_OF_DAY) + ":" + primaryCl.get(Calendar.MINUTE) + ":" + primaryCl.get(Calendar.SECOND);
			String strPrimaryData = primaryEventType.getType() + "\t" + strPrimaryDate + "\t" + strPrimaryTime + "\t" + primaryEventType.getSource() 
								+ "\t" + primaryEventType.getCategory() + "\t" + primaryEventType.getEventID() + "\tSynthetic\tDummy\n";

			writer.write(strPrimaryData);
			
			if(i % 2 == 1){
				millTime += firstPeriod * 1000;
				//	add noise
				if(random < noiseRate){
					millTime +=  random * 100000;
				}
			}
			else{
				millTime += secondPeriod * 1000;
				//	add noise
				if(random < noiseRate){
					millTime +=  random * 100000;
				}
			}
			
			Date secondaryDate = new Date(millTime);
			Calendar secondaryCl = Calendar.getInstance();
			secondaryCl.setTime(secondaryDate);
			String strSecondaryDate = secondaryCl.get(Calendar.YEAR) + "-" + secondaryCl.get(Calendar.MONTH) + "-" + secondaryCl.get(Calendar.DATE);
			String strSecondaryTime = secondaryCl.get(Calendar.HOUR_OF_DAY) + ":" + secondaryCl.get(Calendar.MINUTE) + ":" + secondaryCl.get(Calendar.SECOND);
			String strSecondaryData = secondaryEventType.getType() + "\t" + strSecondaryDate + "\t" + strSecondaryTime + "\t" + secondaryEventType.getSource() 
								+ "\t" + secondaryEventType.getCategory() + "\t" + secondaryEventType.getEventID() + "\tSynthetic\tDummy\n";

			writer.write(strSecondaryData);
		}
	}
	
	public void generateData(String outputPath, List<Pattern> patternList, double noiseRate, double randomRate) throws IOException{
		FileWriter writer = new FileWriter(outputPath);
		writer.write("Type\tDate\tTime\tSource\tCategory\tEvent\tUser\tComputer\n");
		for(Pattern pattern : patternList){
			if(pattern instanceof PeriodPattern){
				this.generatePeriodPattern((PeriodPattern)pattern, writer, noiseRate, randomRate);
			}
			else if(pattern instanceof CorrelationPattern){
				this.generateCorrelationPattern((CorrelationPattern)pattern, writer, noiseRate, randomRate);
			}
		}
		writer.close();
	}
	
	/**
	 * Generate the synthetic dataset according to given parameters.
	 * @param filePath					Output file path.
	 * @param periodPatternNumber		Number of period patterns.
	 * @param correlationPatternSize	Number of correlation patterns.
	 * @param distinctEventTypeSize		Number of distinct event types.
	 * @param noiseRate					Rate of noise.
	 * @param patternLength				The length of each pattern
	 * @throws IOException
	 */
	public void generateDataset(String filePath, int periodPatternNumber, int correlationPatternSize, int distinctEventTypeSize, double noiseRate, int patternLength, double randomRate) throws IOException{
		String[] types = new String[distinctEventTypeSize];
		String[] sources = new String[distinctEventTypeSize];
		String[] categories = new String[distinctEventTypeSize];
		Event[] events = new Event[distinctEventTypeSize];
		for(int i = 0; i < distinctEventTypeSize; ++i){
			types[i] = "type" + i;
			sources[i] = "source" + i;
			categories[i] = "category" + i;
			events[i] = new Event(types[i], sources[i], categories[i], i);
		}
		
		List<Pattern> listPatterns = new ArrayList<Pattern>();
		for(int i = 0; i < periodPatternNumber; ++i){
			int eventType = (int)(Math.random() * distinctEventTypeSize);
			Pattern p = new PeriodPattern(patternLength, 2, 0, events[eventType]);
			listPatterns.add(p);
		}
		
		for(int i = 0; i < correlationPatternSize; ++i){
			int primaryEventType = (int)(Math.random() * distinctEventTypeSize);
			int secondaryEventType = (int)(Math.random() * distinctEventTypeSize);
			Pattern p = new CorrelationPattern(patternLength, 2, 3, events[primaryEventType], events[secondaryEventType]);
			listPatterns.add(p);
		}
		Collections.shuffle(listPatterns);
		
		this.generateData(filePath, listPatterns, noiseRate, randomRate);
	}
	
	/**
	 * Insert intentionally period patterns and correlation patterns with specified noise rate.
	 * @param outputFilePath
	 * @param noiseRate
	 * @throws IOException 
	 */
	public void generateIntentionalPattensData(String outputFilePath, double noiseRate, double randomRate) throws IOException{
		List<Pattern> listPatterns = new ArrayList<Pattern>();

		int numberOfPeriodPattern = 50;
		int numberOfCorrelationPattern = 50;
		int patternLength = 100;
		int distinctEventTypeSize = 150;
		
		String[] types = new String[distinctEventTypeSize];
		String[] sources = new String[distinctEventTypeSize];
		String[] categories = new String[distinctEventTypeSize];
		
		Event[] events = new Event[distinctEventTypeSize];
		for(int i = 0; i < distinctEventTypeSize; ++i){
			types[i] = "type" + i;
			sources[i] = "source" + i;
			categories[i] = "category" + i;
			events[i] = new Event(types[i], sources[i], categories[i], i);
		}
		
		Pattern[] patterns = new Pattern[numberOfPeriodPattern + numberOfCorrelationPattern];
		//	plug in period patterns
		for(int i = 0; i < numberOfPeriodPattern; ++i){
			patterns[i] = new PeriodPattern(patternLength, i + 1, 0, events[i]);
			listPatterns.add(patterns[i]);
		}
		
		//	plug in correlation patterns
		for(int i = 0; i < numberOfCorrelationPattern; ++i){
			patterns[i + numberOfPeriodPattern] = new CorrelationPattern(patternLength, i + 1, 0, events[i + numberOfPeriodPattern], events[(i + numberOfPeriodPattern) + numberOfCorrelationPattern]);
			listPatterns.add(patterns[i + numberOfPeriodPattern]);
		}
		
		
		this.generateData(outputFilePath, listPatterns, noiseRate, randomRate);
	}
	
	/**
	 * Generate dataset with only one period pattern to test the effectiveness of wavelet segmentation.
	 * @param noiseRate
	 * @throws IOException 
	 */
	private void singlePeroidPatternGenerator(String filePath, double noiseRate, double randomRate) throws IOException{
		List<Pattern> listPatterns = new ArrayList<Pattern>();

		int patternLength = 1000;
		Event event = new Event("type1", "source1", "category1", 1);
		Pattern pattern = new PeriodPattern(patternLength, 10, 0, event);
		listPatterns.add(pattern);
		
		this.generateData(filePath, listPatterns, noiseRate, randomRate);
	}
	
	/**
	 * Generate dataset with only one correlation pattern to test the effectiveness of wavelet segmentation.
	 * @param noiseRate
	 * @throws IOException 
	 */
	private void singlePeroidCorrelationGenerator(String filePath, double noiseRate, double randomRate) throws IOException{
		List<Pattern> listPatterns = new ArrayList<Pattern>();

		int patternLength = 1000;
		Event primaryEvent = new Event("type1", "source1", "category1", 1);
		Event secondaryEvent = new Event("type2", "source2", "category2", 2);
		
		Pattern pattern = new CorrelationPattern(patternLength, 10, 0, primaryEvent, secondaryEvent);
		listPatterns.add(pattern);
		
		this.generateData(filePath, listPatterns, noiseRate, randomRate);
	}
	
	/**
	 * Generate 10 synthetic datasets to test the wavelet segmentation effectiveness.
	 * @throws IOException
	 */
	public void generateSinglePeriodPatterns() throws IOException{
		String filePath = "./data/synthetic/singlePeriod";
		double noiseBase = 0.05;
		for(int i = 0; i < 10; ++i){
			this.singlePeroidPatternGenerator(filePath + (i + 1), noiseBase + i * 0.05, 0.0);
		}
	}
	
	/**
	 * Generate data with fix length to test the scalability
	 * @param filePath
	 * @param noiseRate
	 * @param randomRate
	 * @throws IOException 
	 */
	private void generateDataWithFixLength(String outputPath, int numberOfPeriodPattern, int numberOfCorrelationPattern, int distinctEventTypeSize, int patternLength, int length, double noiseRate, double randomRate) throws IOException{
		List<Pattern> listPatterns = new ArrayList<Pattern>();

		String[] types = new String[distinctEventTypeSize];
		String[] sources = new String[distinctEventTypeSize];
		String[] categories = new String[distinctEventTypeSize];
		
		Event[] events = new Event[distinctEventTypeSize];
		for(int i = 0; i < distinctEventTypeSize; ++i){
			types[i] = "type" + i;
			sources[i] = "source" + i;
			categories[i] = "category" + i;
			events[i] = new Event(types[i], sources[i], categories[i], i);
		}
		
		Pattern[] patterns = new Pattern[numberOfPeriodPattern + numberOfCorrelationPattern];
		//	plug in period patterns
		for(int i = 0; i < numberOfPeriodPattern; ++i){
			int randomEventIdx = (int)(Math.random() * distinctEventTypeSize);
			randomEventIdx = i;
			patterns[i] = new PeriodPattern(patternLength, i + 1, 0, events[randomEventIdx]);
			listPatterns.add(patterns[i]);
		}
		
		//	plug in correlation patterns
		for(int i = 0; i < numberOfCorrelationPattern; ++i){
			int randomIdx1 = (int)(Math.random() * distinctEventTypeSize);
			int randomIdx2 = (int)(Math.random() * distinctEventTypeSize);
			randomIdx1 = i;
			randomIdx2 = i + numberOfPeriodPattern;
			patterns[i + numberOfPeriodPattern] = new CorrelationPattern(patternLength, i + 1, 0, events[randomIdx1], events[randomIdx2]);
			listPatterns.add(patterns[i + numberOfPeriodPattern]);
		}
		
		this.generateData(outputPath, listPatterns, noiseRate, randomRate);
		
		//	generate random event instances
		boolean append = true;
		FileWriter writer = new FileWriter(outputPath, append);
		
		int leftLength = length - (numberOfPeriodPattern + 2 * numberOfCorrelationPattern) * patternLength;
		
		long curMillTime = System.currentTimeMillis();
		int randomRange = 1000;
		for(int i = 0; i < leftLength; ++i){
			double random = Math.random();
			int randomIncr = (int)(random * 1000) * randomRange;
			curMillTime += randomIncr;
			int randomEventIdx = (int)(random * distinctEventTypeSize);
			Event primaryEventType = events[randomEventIdx];
			
			Date primaryDate = new Date(curMillTime);
			Calendar primaryCl = Calendar.getInstance();
			primaryCl.setTime(primaryDate);
			String strPrimaryDate = primaryCl.get(Calendar.YEAR) + "-" + primaryCl.get(Calendar.MONTH) + "-" + primaryCl.get(Calendar.DATE);
			String strPrimaryTime = primaryCl.get(Calendar.HOUR_OF_DAY) + ":" + primaryCl.get(Calendar.MINUTE) + ":" + primaryCl.get(Calendar.SECOND);
			String strPrimaryData = primaryEventType.getType() + "\t" + strPrimaryDate + "\t" + strPrimaryTime + "\t" + primaryEventType.getSource() 
								+ "\t" + primaryEventType.getCategory() + "\t" + primaryEventType.getEventID() + "\tSynthetic\tDummy\n";
			writer.write(strPrimaryData);
		}
		writer.close();
	}
	
	/**
	 * Generate 5 datasets with fix length to test the scalability of algorithm.
	 * @throws IOException 
	 */
	public void generateDataWithFixLength() throws IOException{
		String filePath = "./data/synthetic/scalability";
		
		this.generateDataWithFixLength(filePath + 1, 100, 0, 100, 25, 2500, 0.1, 0.0);
		this.generateDataWithFixLength(filePath + 2, 100, 0, 100, 50, 5000, 0.1, 0.0);
		this.generateDataWithFixLength(filePath + 3, 100, 0, 100, 75, 7500, 0.1, 0.0);
		this.generateDataWithFixLength(filePath + 4, 100, 0, 100, 100, 10000, 0.1, 0.0);
		this.generateDataWithFixLength(filePath + 5, 100, 0, 100, 200, 20000, 0.1, 0.0);
	}
	
	/**
	 * Generate 5 datasets with fix proportion of patterns to test the CR vs proportion.
	 * @throws IOException
	 */
	public void generateDataWithFixProportion() throws IOException{
		String filePath = "./data/synthetic/proportion";
		
		this.generateDataWithFixLength(filePath + 1, 5, 0, 50, 100, 5000, 0.1, 0.0);	//	10%
		this.generateDataWithFixLength(filePath + 2, 10, 0, 50, 100, 5000, 0.1, 0.0);	//	20%
		this.generateDataWithFixLength(filePath + 3, 15, 0, 50, 100, 5000, 0.1, 0.0);	//	30%
		this.generateDataWithFixLength(filePath + 4, 20, 0, 50, 100, 5000, 0.1, 0.0);	//	40%
		this.generateDataWithFixLength(filePath + 5, 25, 0, 50, 100, 5000, 0.1, 0.0);	//	50%
		this.generateDataWithFixLength(filePath + 6, 30, 0, 50, 100, 5000, 0.1, 0.0);	//	60%
		this.generateDataWithFixLength(filePath + 7, 35, 0, 50, 100, 5000, 0.1, 0.0);	//	70%
		this.generateDataWithFixLength(filePath + 8, 40, 0, 50, 100, 5000, 0.1, 0.0);	//	80%
	}
	
	/**
	 * Generate 5 dataset with fix length but with different number of event types.
	 * @throws IOException
	 */
	public void generateDataWithDistinctNumberOfEvents() throws IOException{
		String filePath = "./data/synthetic/distinctEvents";
		
		
		this.generateDataWithFixLength(filePath + 1, 4, 0, 4, 1024, 2048, 0.1, 0.0);	//	40
		this.generateDataWithFixLength(filePath + 2, 8, 0, 8, 512, 2048, 0.1, 0.0);	//	60
		this.generateDataWithFixLength(filePath + 3, 16, 0, 16, 256, 2048, 0.1, 0.0);	//	80
		this.generateDataWithFixLength(filePath + 4, 32, 0, 32, 128, 2048, 0.1, 0.0);	//	100
		this.generateDataWithFixLength(filePath + 5, 64, 0, 64, 64, 2048, 0.1, 0.0);	//	100
		this.generateDataWithFixLength(filePath + 6, 128, 0, 128, 32, 2048, 0.1, 0.0);	//	40

	}
	
	public void smallDataset() throws IOException{
		String output = "./data/real/small";

		List<Pattern> listPatterns = new ArrayList<Pattern>();

		double noiseRate = 0.05;
		int numberOfPeriodPattern = 0;
		int numberOfCorrelationPattern = 1;
		int patternLength = 100;
		int distinctEventTypeSize = 10;
		
		String[] types = new String[distinctEventTypeSize];
		String[] sources = new String[distinctEventTypeSize];
		String[] categories = new String[distinctEventTypeSize];
		
		Event[] events = new Event[distinctEventTypeSize];
		for(int i = 0; i < distinctEventTypeSize; ++i){
			types[i] = "type" + i;
			sources[i] = "source" + i;
			categories[i] = "category" + i;
			events[i] = new Event(types[i], sources[i], categories[i], i);
		}
		
		Pattern[] patterns = new Pattern[numberOfPeriodPattern + numberOfCorrelationPattern];
		//	plug in period patterns
		for(int i = 0; i < numberOfPeriodPattern; ++i){
			double random = Math.random();
			Event event = events[(int)(random * distinctEventTypeSize)];
			patterns[i] = new PeriodPattern(patternLength, i + 1, 0, event);
			listPatterns.add(patterns[i]);
			System.out.println("Period: Add " + event + " with interval " + (i + 1));
		}
		
		//	plug in correlation patterns
		Random r = new Random();
		for(int i = 0; i < numberOfCorrelationPattern; ++i){
			double random1 = r.nextDouble();
			int random2 = r.nextInt() % distinctEventTypeSize;
			Event primaryEvent = events[(int)(random1 * distinctEventTypeSize)];
			Event secondaryEvent = events[Math.abs(random2)];
			
			patterns[i + numberOfPeriodPattern] = new CorrelationPattern(patternLength, 3, 0, primaryEvent, secondaryEvent);
			listPatterns.add(patterns[i + numberOfPeriodPattern]);
			System.out.println("Correlation: Add " + primaryEvent +  " and " + secondaryEvent + " with interval " + (i + 1));
		}
		
		
		this.generateData(output, listPatterns, noiseRate, 0.0);
		
	}
	
	public static void main(String[] args) throws IOException{
		SyntheticDataGenerator gen = new SyntheticDataGenerator();
		List<Pattern> patternList = new ArrayList<Pattern>();
		
		int distinctEventTypes = 100;
		double randomRate = 0.8;
		
		String outputPath = "./data/synthetic/synthetic";
		
		//	generate precison and CR vs noise experiment data
//		gen.generateIntentionalPattensData(outputPath + 1, 0.1, randomRate);
//		gen.generateIntentionalPattensData(outputPath + 2, 0.2, randomRate);
//		gen.generateIntentionalPattensData(outputPath + 3, 0.3, randomRate);
//		gen.generateIntentionalPattensData(outputPath + 4, 0.4, randomRate);
//		gen.generateIntentionalPattensData(outputPath + 5, 0.5, randomRate);
//		gen.generateIntentionalPattensData(outputPath + 6, 0.6, randomRate);
//		
//		//	generate noise vs wavelet segmentation data
////		gen.generateSinglePeriodPatterns();
//		
//		//	generate scalability experiment data
//		gen.generateDataWithFixLength();
//		
//		//	generate CR vs pattern proportion experiment data
		gen.generateDataWithFixProportion();
//		
//		//	generate Running time vs m
//		gen.generateDataWithDistinctNumberOfEvents();
		
//		gen.smallDataset();
	}
}
